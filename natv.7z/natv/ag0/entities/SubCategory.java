package natv.ag0.entities;

import org.codehaus.jackson.annotate.JsonBackReference;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonManagedReference;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

import javax.persistence.*;
import java.util.List;

@Entity
@Indexed
@Table(name = "sub_categories")
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler", "order"})
public class SubCategory {

    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    private Long id;

//    @JsonBackReference(value = "category-sub_category")
    @JsonBackReference
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    @IndexedEmbedded
    private Category category;

    @Field
    private String name;

//    @JsonManagedReference(value = "sub_category-order")
    @OneToMany(mappedBy = "sub_category", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Order> order;

    public SubCategory(){}
    public SubCategory(Long id) {
        this.id = id;
    }
    public SubCategory(Long id, Category category, String name) {
        this.id = id;
        this.category = category;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Order> getOrder() {
        return order;
    }

    public void setOrder(List<Order> order) {
        this.order = order;
    }
}
