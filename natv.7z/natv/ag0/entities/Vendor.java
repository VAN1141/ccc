package natv.ag0.entities;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonManagedReference;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.search.annotations.*;

import javax.persistence.*;
import java.math.BigInteger;
import java.util.List;

@Entity
@Indexed
@Table(name = "vendors")
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler", "order"})
public class Vendor {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "name")
    @Field
    private String name;

    @Field
    private String person_in_charge;

    @Field
    private String telephone_number;

    @Field
    private String website;

    @Field
    private String mobile_number;

    @Field
    private String email;

    @Field
    private String address;
    private String establish_year;
    private Integer number_of_employees;
    private String branch;
    private String financial_report;
    private  Integer rate;
    @Transient
    private BigInteger category_rate;

    @Transient
    private Long count;

    @JsonManagedReference(value = "vendor-order")
    @OneToMany(mappedBy = "vendor", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Order> order;

    public Vendor() {}
    public Vendor(Long id) {
        this.id = id;
    }

    public Vendor(Long id, String name, String person_in_charge, String telephone_number, String website, String mobile_number, String email, String address, String establish_year, Integer number_of_employees, String branch, String financial_report, List<Order> order) {
        this.id = id;
        this.name = name;
        this.person_in_charge = person_in_charge;
        this.telephone_number = telephone_number;
        this.website = website;
        this.mobile_number = mobile_number;
        this.email = email;
        this.address = address;
        this.establish_year = establish_year;
        this.number_of_employees = number_of_employees;
        this.branch = branch;
        this.financial_report = financial_report;
        this.order = order;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPerson_in_charge() {
        return person_in_charge;
    }

    public void setPerson_in_charge(String person_in_charge) {
        this.person_in_charge = person_in_charge;
    }

    public String getTelephone_number() {
        return telephone_number;
    }

    public void setTelephone_number(String telephone_number) {
        this.telephone_number = telephone_number;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(String mobile_number) {
        this.mobile_number = mobile_number;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEstablish_year() {
        return establish_year;
    }

    public void setEstablish_year(String establish_year) {
        this.establish_year = establish_year;
    }

    public Integer getNumber_of_employees() {
        return number_of_employees;
    }

    public void setNumber_of_employees(Integer number_of_employees) {
        this.number_of_employees = number_of_employees;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getFinancial_report() {
        return financial_report;
    }

    public void setFinancial_report(String financial_report) {
        this.financial_report = financial_report;
    }

    public Integer getRate() {
        return rate;
    }

    public void setRate(Integer rate) {
        this.rate = rate;
    }

    public BigInteger getCategory_rate() {
        return category_rate;
    }

    public void setCategory_rate(BigInteger category_rate) {
        this.category_rate = category_rate;
    }

    public List<Order> getOrder() {
        return order;
    }

    public void setOrder(List<Order> order) {
        this.order = order;
    }

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }
}
