package natv.ag0.entities;

import org.codehaus.jackson.annotate.JsonBackReference;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

import javax.persistence.*;

@Entity
@Indexed
@Table(name = "orders")
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Field
    private String request_date;

    @Field
    private String request_department;

    @Field
    private String request_group;

    @Field
    private String case_number;

//    @JsonBackReference(value = "sub_category-order")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sub_category_id")
    @IndexedEmbedded
    private SubCategory sub_category;

//    @JsonBackReference(value = "vendor-order")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vendor_id")
    @IndexedEmbedded
    private Vendor vendor;

    @Field
    private String description;

    @Field
    private String description_vn;

    @Field
    private String maker;

    @Field
    private String model;
    private Long price;
    private String currency;
    private String unit;
    private Integer quantity;
    private Integer rate;
    private String link;

    public Order() {}

    public Order(Long id) {
        this.id = id;
    }

    public Order(Long id, String request_date, String request_department, String request_group, String case_number, Vendor vendor, String description, String description_vn, String maker, String model, Long price, String currency, String unit, Integer quantity, Integer rate) {
        this.id = id;
        this.request_date = request_date;
        this.request_department = request_department;
        this.request_group = request_group;
        this.case_number = case_number;
        this.vendor = vendor;
        this.description = description;
        this.description_vn = description_vn;
        this.maker = maker;
        this.model = model;
        this.price = price;
        this.currency = currency;
        this.unit = unit;
        this.quantity = quantity;
        this.rate = rate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public SubCategory getSub_category() {
        return sub_category;
    }

    public void setSub_category(SubCategory sub_category) {
        this.sub_category = sub_category;
    }

    public Vendor getVendor() { return vendor; }

    public void setVendor(Vendor vendor) {
        this.vendor = vendor;
    }

    public String getRequest_date() {
        return request_date;
    }

    public void setRequest_date(String request_date) {
        this.request_date = request_date;
    }

    public String getRequest_department() {
        return request_department;
    }

    public void setRequest_department(String request_department) {
        this.request_department = request_department;
    }

    public String getRequest_group() {
        return request_group;
    }

    public void setRequest_group(String request_group) {
        this.request_group = request_group;
    }

    public String getCase_number() {
        return case_number;
    }

    public void setCase_number(String case_number) {
        this.case_number = case_number;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription_vn() {
        return description_vn;
    }

    public void setDescription_vn(String description_vn) {
        this.description_vn = description_vn;
    }

    public String getMaker() {
        return maker;
    }

    public void setMaker(String maker) {
        this.maker = maker;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Long getPrice() {
        return price;
    }

    public void setPrice(Long price) {
        this.price = price;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getRate() {
        return rate;
    }

    public void setRate(Integer rate) {
        this.rate = rate;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }


}
