package natv.ag0.entities;

import java.util.List;

public class ListVendor {
    private Long total;
    private Integer page;
    private List<Vendor> vendors;

    public ListVendor() {}
    public ListVendor(Long total, Integer page, List<Vendor> vendors) {
        this.total = total;
        this.page = page;
        this.vendors = vendors;
    }

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public List<Vendor> getVendors() {
        return vendors;
    }

    public void setVendors(List<Vendor> vendors) {
        this.vendors = vendors;
    }
}
