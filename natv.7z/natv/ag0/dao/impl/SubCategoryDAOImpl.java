package natv.ag0.dao.impl;

import natv.ag0.dao.SubCategoryDAO;
import natv.ag0.entities.SubCategory;
import natv.ag0.utils.MyNotify;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class SubCategoryDAOImpl implements SubCategoryDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public List<SubCategory> getAllSubCategory() {
        Session session = sessionFactory.getCurrentSession();
        List<SubCategory> results = session.createCriteria(SubCategory.class).list();
        for (SubCategory result : results) {
            Hibernate.initialize(result.getCategory());
        }
        return results;
    }

    public SubCategory getSubCategoryById(Long id) {
        Session session = sessionFactory.getCurrentSession();
        SubCategory result = (SubCategory) session.get(SubCategory.class, id);
        if (result != null) {
            result.setOrder(null);
            Hibernate.initialize(result.getCategory());
        }
        return result;
    }

    public List<SubCategory> getSubCategoryByCategoryId(Long parent_id) {
        Session session = sessionFactory.getCurrentSession();
        List<SubCategory> results = session.createCriteria(SubCategory.class)
                .add(Restrictions.eq("category.id", parent_id))
                .list();
        for (SubCategory result : results) {
            Hibernate.initialize(result.getCategory());
        }
        return results;
    }

    public MyNotify createSubCategory(SubCategory subCategory) {
        MyNotify response = new MyNotify();
        Session session = sessionFactory.getCurrentSession();
        try {
            session.save(subCategory);
            response.setType("success");
            response.setMessage(subCategory.getName() + " has been created!");
        } catch (Exception e){
            response.setType("error");
            response.setMessage(e.getMessage());
        }
        return response;
    }

    public MyNotify updateSubCategory(SubCategory subCategory) {
        MyNotify response = new MyNotify();
        Session session = sessionFactory.getCurrentSession();
        Object isExist = session.get(SubCategory.class, subCategory.getId());
        if (null == isExist) {
            response.setType("error");
            response.setMessage("Can't update this Subcategory. Subcategory with id:" + subCategory.getId() + " is not found on database.");
        } else {
            try {
                session.clear();
                session.update(subCategory);
                response.setType("success");
                response.setMessage(subCategory.getName() + " has been updated!");
            } catch (Exception e){
                response.setType("error");
                response.setMessage(e.getMessage());
            }
        }
        return response;
    }

    public MyNotify deleteSubCategory(SubCategory subCategory) {
        MyNotify response = new MyNotify();
        Session session = sessionFactory.getCurrentSession();
        SubCategory isExist = (SubCategory) session.get(SubCategory.class, subCategory.getId());
        if (null == isExist) {
            response.setType("error");
            response.setMessage("Can't delete this Subcategory. Subcategory with id:" + subCategory.getId() + " is not found on database.");
        } else {
            try {
                String name = isExist.getName();
                session.clear();
                session.delete(subCategory);
                response.setType("success");
                response.setMessage(name + " has been deleted!");
            } catch (Exception e){
                response.setType("error");
                response.setMessage(e.getMessage());
            }
        }
        return response;
    }
}
