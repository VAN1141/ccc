package natv.ag0.dao.impl;

import natv.ag0.dao.CategoryDAO;
import natv.ag0.entities.Category;
import natv.ag0.utils.MyNotify;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class CategoryDAOImpl implements CategoryDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public Category getCategoryById(Long id) {
		Session session = sessionFactory.getCurrentSession();
		Category result = (Category) session.get(Category.class, id);
		if (result != null) {
			Hibernate.initialize(result.getSub_category());
		}
		return  result;
	}

	public List<Category> getAllCategory() {
		Session session = sessionFactory.getCurrentSession();
		List<Category> result = session.createCriteria(Category.class).addOrder(Order.asc("id")).list();
		for (Category category: result) {
			Hibernate.initialize(category.getSub_category());
		}
		return  result;
	}

	public List<Category> getAllCategoryList() {
		Session session = sessionFactory.getCurrentSession();
		List<Category> result = session.createCriteria(Category.class).list();
		session.clear();
		for (Category category: result) {
//			Hibernate.initialize(category.getSub_category());
			category.setSub_category(null);
		}
		return  result;
	}

	public MyNotify createCategory(Category category) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		try {
			session.save(category);
			response.setType("success");
			response.setMessage(category.getName() + " has been created!");
		} catch (Exception e){
			response.setType("error");
			response.setMessage(e.getMessage());
		}
		return response;
	}

	public MyNotify updateCategory(Category category) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		Object isExist = session.get(Category.class, category.getId());
		if (null == isExist) {
			response.setType("error");
			response.setMessage("Can't update this Category. Category with id:" + category.getId() + " is not found on database.");
		} else {
			try {
				session.clear();
				session.update(category);
				response.setType("success");
				response.setMessage(category.getName() + " has been updated!");
			} catch (Exception e) {
				response.setType("error");
				response.setMessage(e.getMessage());
			}
		}
		return response;
	}

	public MyNotify deleteCategory(Category category) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		Category isExist = (Category) session.get(Category.class, category.getId());
		if (null == isExist) {
			response.setType("error");
			response.setMessage("Can't delete this Subcategory. Subcategory with id:" + category.getId() + " is not found on database.");
		} else {
			try {
				String name = isExist.getName();
				session.clear();
				session.delete(category);
				response.setType("success");
				response.setMessage(name + " has been deleted!");
			} catch (Exception e){
				response.setType("error");
				response.setMessage(e.getMessage());
			}
		}
		return response;
	}
}