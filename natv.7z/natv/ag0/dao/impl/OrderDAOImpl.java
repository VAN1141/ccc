package natv.ag0.dao.impl;

import natv.ag0.dao.OrderDAO;
import natv.ag0.entities.Order;
import natv.ag0.utils.MyNotify;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class OrderDAOImpl implements OrderDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public Order getOrderById(Long id) {
		Session session = sessionFactory.getCurrentSession();
		Order result = (Order) session.get(Order.class, id);
		if (result != null) {
			Hibernate.initialize(result.getVendor());
			Hibernate.initialize(result.getSub_category());
		}
		return result;
	}

	public List<Order> getAllOrder() {
		Session session = sessionFactory.getCurrentSession();
		List<Order> results = session.createCriteria(Order.class)
				.setMaxResults(200)
				.list();
		if (results != null) {
			for (Order result : results) {
				Hibernate.initialize(result.getVendor());
				Hibernate.initialize(result.getSub_category());
			}
		}
		return results;
	}

	public List<Order> getOrderByVendorId(Long vendor_id) {
		Session session = sessionFactory.getCurrentSession();
		List<Order> results =  session.createCriteria(Order.class)
				.add(Restrictions.eq("vendor.id", vendor_id))
				.setMaxResults(200)
				.list();
		if (results != null) {
			for (Order result : results) {
				Hibernate.initialize(result.getVendor());
				Hibernate.initialize(result.getSub_category());
			}
		}
		return results;
	}

	public List<Order> getOrderBySubCategoryId(Long sub_category_id) {
		Session session = sessionFactory.getCurrentSession();
		List<Order> results =  session.createCriteria(Order.class)
				.add(Restrictions.eq("sub_category.id", sub_category_id))
				.setMaxResults(200)
				.list();
		if (results != null) {
			for (Order result : results) {
				Hibernate.initialize(result.getVendor());
				Hibernate.initialize(result.getSub_category());
			}
		}
		return results;
	}

	public List<Order> getOrderBySubCategoryIdAndVendorId(Long sub_category_id, Long vendor_id) {
		Session session = sessionFactory.getCurrentSession();
		List<Order> results =  session.createCriteria(Order.class)
				.add(Restrictions.eq("sub_category.id", sub_category_id))
				.add(Restrictions.eq("vendor.id", vendor_id))
				.setMaxResults(200)
				.list();
		if (results != null) {
			for (Order result : results) {
				Hibernate.initialize(result.getVendor());
				Hibernate.initialize(result.getSub_category());
			}
		}
		return results;
	}

	public MyNotify createOrder(Order order) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		try {
			session.save(order);
			response.setType("success");
			response.setMessage("Order has been created!");
		} catch (Exception e){
			response.setType("error");
			response.setMessage(e.getMessage());
		}
		return response;
	}

	public MyNotify updateOrder(Order order) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		Object isExist = session.get(Order.class, order.getId());
		if (null == isExist) {
			response.setType("error");
			response.setMessage("Can't update this Order. Order with id:" + order.getId() + " is not found on database.");
		} else {
			try {
				session.clear();
				session.update(order);
				response.setType("success");
				response.setMessage("Order  has been updated!");
			} catch (Exception e){
				response.setType("error");
				response.setMessage(e.getMessage());
			}
		}
		return response;
	}

	public MyNotify deleteOrder(Order order) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		Object isExist = session.get(Order.class, order.getId());
		if (null == isExist) {
			response.setType("error");
			response.setMessage("Can't delete this Order. Order with id:" + order.getId() + " is not found on database.");
		} else {
			try {
				session.clear();
				session.delete(order);
				response.setType("success");
				response.setMessage("Order has been deleted!");
			} catch (Exception e){
				response.setType("error");
				response.setMessage(e.getMessage());
			}
		}
		return response;
	}

	public List<Order> searchOrder(String keyword){
		Session session = sessionFactory.getCurrentSession();
		List<Order> results = null;
		try {
			FullTextSession fullTextSession = Search.getFullTextSession(session);

			QueryBuilder qb = fullTextSession.getSearchFactory()
					.buildQueryBuilder().forEntity(Order.class).get();
			org.apache.lucene.search.Query query = qb
					.keyword().onFields("request_department", "request_group", "description", "description_vn", "maker", "model")
					.andField("vendor.name").boostedTo(2f)
					.andField("sub_category.name").boostedTo(2f)
					.andField("case_number").boostedTo(5f)
					.matching(keyword)
					.createQuery();

			org.hibernate.Query hibQuery =
					fullTextSession.createFullTextQuery(query, Order.class);

			results = (List<Order>) hibQuery
					.setMaxResults(200)
					.list();
			if (results != null) {
				for (Order result : results) {
					Hibernate.initialize(result.getVendor());
					Hibernate.initialize(result.getSub_category());
				}
			}
			return results;
		} catch (Exception e) {
//			Do nothing
		}
		return results;
	}
}