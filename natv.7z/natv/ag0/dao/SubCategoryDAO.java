package natv.ag0.dao;

import natv.ag0.entities.Category;
import natv.ag0.entities.SubCategory;
import natv.ag0.utils.MyNotify;

import java.util.List;

/**
 * Created by nguyen.viet.anhc on 29/11/2016.
 */
public interface SubCategoryDAO {
	SubCategory getSubCategoryById(Long id);
	List<SubCategory> getSubCategoryByCategoryId(Long id);
	MyNotify createSubCategory(SubCategory subCategory);
	MyNotify updateSubCategory(SubCategory subCategory);
	MyNotify deleteSubCategory(SubCategory subCategory);

	List<SubCategory> getAllSubCategory();
}
