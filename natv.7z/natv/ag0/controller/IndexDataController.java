package natv.ag0.controller;

import natv.ag0.utils.IndexData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@Controller
public class IndexDataController {
    @Autowired
    private IndexData indexData;

    @ResponseBody
    @RequestMapping(value = "/category/indexdata", method = RequestMethod.GET)
    public ResponseEntity indexCategory() {
        return indexData.indexCategory();
    }


    @ResponseBody
    @RequestMapping(value = "/sub_category/indexdata", method = RequestMethod.GET)
    public ResponseEntity indexSubCategory() {
        return indexData.indexSubCategory();
    }


    @ResponseBody
    @RequestMapping(value = "/vendor/indexdata", method = RequestMethod.GET)
    public ResponseEntity indexVendor() {
        return indexData.indexVendor();
    }

    @ResponseBody
    @RequestMapping(value = "/order/indexdata", method = RequestMethod.GET)
    public ResponseEntity indexOrder() {
        return indexData.indexOrder();
    }

    @ResponseBody
    @RequestMapping(value = "/indexdata", method = RequestMethod.GET)
    public ResponseEntity indexData() {
        return indexData.indexAll();
    }
}
