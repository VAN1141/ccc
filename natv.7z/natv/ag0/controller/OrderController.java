package natv.ag0.controller;

import natv.ag0.dao.OrderDAO;
import natv.ag0.entities.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;

@Controller
public class OrderController {
	@Autowired
	OrderDAO orderDAO;

	@ResponseBody
	@RequestMapping(value = "/order", method = RequestMethod.GET)
	public ResponseEntity getAllOrder() {
		Object result =  orderDAO.getAllOrder();
		if(null == result) {
			return new ResponseEntity("[]", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/order/{id}", method = RequestMethod.GET)
	public ResponseEntity getOrderById(@PathVariable("id") Long id) {
		Object result =  orderDAO.getOrderById(id);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/vendor/{id}/order", method = RequestMethod.GET)
	public ResponseEntity getOrderByVendorId(@PathVariable("id") Long id) {
		Object result =  orderDAO.getOrderByVendorId(id);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/sub_category/{id}/order", method = RequestMethod.GET)
	public ResponseEntity getOrderBySubCategoryId(@PathVariable("id") Long id) {
		Object result =  orderDAO.getOrderBySubCategoryId(id);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/sub_category/{sub_category_id}/vendor/{vendor_id}/order", method = RequestMethod.GET)
	public ResponseEntity getOrderBySubCategoryIdAndVendorId(@PathVariable("sub_category_id") Long sub_category_id, @PathVariable("vendor_id") Long vendor_id) {
		Object result =  orderDAO.getOrderBySubCategoryIdAndVendorId(sub_category_id, vendor_id);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}
	@ResponseBody
	@RequestMapping(value = "/vendor/{vendor_id}/sub_category/{sub_category_id}/order", method = RequestMethod.GET)
	public ResponseEntity getOrderByVendorIdAndSubCategoryId(@PathVariable("vendor_id") Long vendor_id, @PathVariable("sub_category_id") Long sub_category_id) {
		Object result =  orderDAO.getOrderBySubCategoryIdAndVendorId(sub_category_id, vendor_id);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/order", method = RequestMethod.POST)
	public ResponseEntity createOrder(@RequestBody Order order) {
		Object result =  orderDAO.createOrder(order);
		return new ResponseEntity( result, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/order/{id}", method = RequestMethod.POST)
	public ResponseEntity updateOrder(@PathVariable("id") Long id, @RequestBody Order order) {
		order.setId(id);
		Object result =  orderDAO.updateOrder(order);
		return new ResponseEntity( result, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/order/{id}", method = RequestMethod.DELETE)
	public ResponseEntity deleteOrder(@PathVariable("id") Long id) {
		Order Order = new Order(id);
		Object result =  orderDAO.deleteOrder(Order);
		return new ResponseEntity( result, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/order/search/{keyword}", method = RequestMethod.GET)
	public ResponseEntity searchOrder(@PathVariable("keyword") String keyword) {
		try {
			keyword = new String(keyword.getBytes("ISO-8859-1"), "UTF-8");
		} catch (UnsupportedEncodingException e) {
//			Do nothing
		}
		Object result =  orderDAO.searchOrder(keyword);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}
}
