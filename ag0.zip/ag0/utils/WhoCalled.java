package natv.ag0.utils;

public class WhoCalled extends SecurityManager {
    public static final WhoCalled INSTANCE = new WhoCalled();
    private static final int OFFSET = 1;
    public Class getCallingClasses() {
        return getClassContext()[OFFSET + 1];
    }
}