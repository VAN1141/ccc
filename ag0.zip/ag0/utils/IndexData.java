package natv.ag0.utils;

import natv.ag0.entities.Category;
import natv.ag0.entities.Order;
import natv.ag0.entities.SubCategory;
import natv.ag0.entities.Vendor;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Repository
@Transactional
public class IndexData {
    @Autowired
    private SessionFactory sessionFactory;

    public ResponseEntity indexAll() {
        try {
            Session session = sessionFactory.getCurrentSession();
            FullTextSession fullTextSession = Search.getFullTextSession(session);
            fullTextSession.createIndexer().startAndWait();
            return new ResponseEntity( "Add data has been indexed at " + new Date().toString(), HttpStatus.OK);
        } catch(Exception e) {
            return new ResponseEntity( e.getMessage(), HttpStatus.OK);
        }
    }

    public ResponseEntity indexCategory() {
        try {
            Session session = sessionFactory.getCurrentSession();
            FullTextSession fullTextSession = Search.getFullTextSession(session);
            fullTextSession.createIndexer(Category.class).startAndWait();
            return new ResponseEntity( "Category has been indexed at " + new Date().toString(), HttpStatus.OK);
        } catch(Exception e) {
            return new ResponseEntity( e.getMessage(), HttpStatus.OK);
        }
    }


    public ResponseEntity indexSubCategory() {
        try {
            Session session = sessionFactory.getCurrentSession();
            FullTextSession fullTextSession = Search.getFullTextSession(session);
            fullTextSession.createIndexer(SubCategory.class).startAndWait();
            return new ResponseEntity( "SubCategory has been indexed at " + new Date().toString(), HttpStatus.OK);
        } catch(Exception e) {
            return new ResponseEntity( e.getMessage(), HttpStatus.OK);
        }
    }

    public ResponseEntity indexVendor() {
        try {
            Session session = sessionFactory.getCurrentSession();
            FullTextSession fullTextSession = Search.getFullTextSession(session);
            fullTextSession.createIndexer(Vendor.class).startAndWait();
            return new ResponseEntity( "Vendor has been indexed at " + new Date().toString(), HttpStatus.OK);
        } catch(Exception e) {
            return new ResponseEntity( e.getMessage(), HttpStatus.OK);
        }
    }

    public ResponseEntity indexOrder() {
        try {
            Session session = sessionFactory.getCurrentSession();
            FullTextSession fullTextSession = Search.getFullTextSession(session);
            fullTextSession.createIndexer(Order.class).startAndWait();
            return new ResponseEntity( "Order has been indexed at " + new Date().toString(), HttpStatus.OK);
        } catch(Exception e) {
            return new ResponseEntity( e.getMessage(), HttpStatus.OK);
        }
    }
}
