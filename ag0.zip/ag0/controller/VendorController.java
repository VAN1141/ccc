package natv.ag0.controller;

import natv.ag0.dao.VendorDAO;
import natv.ag0.entities.Vendor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriUtils;

import java.io.UnsupportedEncodingException;

@Controller
public class VendorController {
	@Autowired
	VendorDAO VendorDAO;


	@ResponseBody
	@RequestMapping(value = "/vendor", method = RequestMethod.GET)
	public ResponseEntity getAllVendor(@RequestParam Integer page) {
		Object result =  VendorDAO.getAllVendorByPage(page);
		return new ResponseEntity( result, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/vendor/list", method = RequestMethod.GET)
	public ResponseEntity getListVendor() {
		Object result =  VendorDAO.getListVendor();
		return new ResponseEntity( result, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/vendor/{id}", method = RequestMethod.GET)
	public ResponseEntity getVendorById(@PathVariable("id") Long id) {
		Object result =  VendorDAO.getVendorById(id);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/sub_category/{id}/vendor", method = RequestMethod.GET)
	public ResponseEntity getVendorBySubCategory(@PathVariable("id") Long id, @RequestParam Integer page) {
		Object result =  VendorDAO.getVendorBySubCategoryId(id, page);
		if(null == result) {
			return new ResponseEntity( "{}", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/vendor/{id}", method = RequestMethod.POST)
	public ResponseEntity updateVendor(@PathVariable("id") Long id, @RequestBody Vendor vendor) {
		vendor.setId(id);
		Object result =  VendorDAO.updateVendor(vendor);
		return new ResponseEntity( result, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/vendor", method = RequestMethod.POST)
	public ResponseEntity createVendor(@RequestBody Vendor Vendor) {
		Object result =  VendorDAO.createVendor(Vendor);
		return new ResponseEntity( result, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/vendor/{id}", method = RequestMethod.DELETE)
	public ResponseEntity deleteVendor(@PathVariable("id") Long id) {
		Vendor Vendor = new Vendor(id);
		Object result =  VendorDAO.deleteVendor(Vendor);
		return new ResponseEntity( result, HttpStatus.OK);
	}
}
