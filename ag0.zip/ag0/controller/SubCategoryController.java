package natv.ag0.controller;

import natv.ag0.dao.CategoryDAO;
import natv.ag0.dao.SubCategoryDAO;
import natv.ag0.entities.Category;
import natv.ag0.entities.SubCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class SubCategoryController {
    @Autowired
    SubCategoryDAO subCategoryDAO;

    @ResponseBody
    @RequestMapping(value = "/sub_category", method = RequestMethod.GET)
    public ResponseEntity getAllSubCategory() {
        Object result =  subCategoryDAO.getAllSubCategory();
        if(null == result) {
            return new ResponseEntity("[]", HttpStatus.OK);
        } else {
            return new ResponseEntity(result, HttpStatus.OK);
        }
    }

    @ResponseBody
    @RequestMapping(value = "/sub_category/{id}", method = RequestMethod.GET)
    public ResponseEntity getSubCategoryById(@PathVariable("id") Long id) {
        Object result =  subCategoryDAO.getSubCategoryById(id);
        if(null == result) {
            return new ResponseEntity("{}", HttpStatus.OK);
        } else {
            return new ResponseEntity(result, HttpStatus.OK);
        }
    }

	@ResponseBody
	@RequestMapping(value = "/category/{id}/sub_category", method = RequestMethod.GET)
	public ResponseEntity getCategoryById(@PathVariable("id") Long id) {
		Object result =  subCategoryDAO.getSubCategoryByCategoryId(id);
		if(null == result) {
			return new ResponseEntity( "[]", HttpStatus.OK);
		} else {
			return new ResponseEntity(result, HttpStatus.OK);
		}
	}

    @ResponseBody
    @RequestMapping(value = "/sub_category/{id}", method = RequestMethod.POST)
    public ResponseEntity updateSubCategory(@PathVariable("id") Long id ,@RequestBody SubCategory subCategory) {
        subCategory.setId(id);
        Object result =  subCategoryDAO.updateSubCategory(subCategory);
        return new ResponseEntity( result, HttpStatus.OK);
    }

    @ResponseBody
    @RequestMapping(value = "/sub_category", method = RequestMethod.POST)
    public ResponseEntity createSubCategory(@RequestBody SubCategory subCategory) {
        Object result =  subCategoryDAO.createSubCategory(subCategory);
        return new ResponseEntity( result, HttpStatus.OK);
    }

    @ResponseBody
    @RequestMapping(value = "/sub_category/{id}", method = RequestMethod.DELETE)
    public ResponseEntity deleteSubCategory(@PathVariable("id") Long id) {
        SubCategory subCategory = new SubCategory(id);
        Object result =  subCategoryDAO.deleteSubCategory(subCategory);
        return new ResponseEntity( result, HttpStatus.OK);
    }
}
