package natv.ag0.dao;

import natv.ag0.entities.Order;
import natv.ag0.utils.MyNotify;

import java.util.List;

public interface OrderDAO {
	Order getOrderById(Long id);
	List<Order> getAllOrder();
	List<Order> getOrderBySubCategoryId(Long sub_category_id);
	List<Order> getOrderByVendorId(Long vendor_id);
	List<Order> getOrderBySubCategoryIdAndVendorId(Long sub_category_id, Long vendor_id);
	MyNotify createOrder(Order Order);
	MyNotify updateOrder(Order Order);
	MyNotify deleteOrder(Order Order);
	List<Order> searchOrder(String keyword);
}
