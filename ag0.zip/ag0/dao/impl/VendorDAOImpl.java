package natv.ag0.dao.impl;

import natv.ag0.dao.VendorDAO;
import natv.ag0.entities.ListVendor;
import natv.ag0.entities.Vendor;
import natv.ag0.utils.MyNotify;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Repository
@Transactional
public class VendorDAOImpl implements VendorDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public ListVendor getAllVendorByPage(Integer page) {
		if (page == null) { page = 1; }
		Session session = sessionFactory.getCurrentSession();
		Long count  = (Long) session.createCriteria(Vendor.class)
				.setProjection(Projections.rowCount())
				.uniqueResult();
		List<Vendor> results = session.createCriteria(Vendor.class)
				.setFirstResult(20*page -20)
				.setMaxResults(20)
				.list();
//		for(Vendor result: results){
//			result.setCount(count/20);
//		}
		ListVendor ret = new ListVendor(count/20, page, results);
		return ret;
	}

	public List<Vendor> getListVendor() {
		Session session = sessionFactory.getCurrentSession();
		List<Vendor> results = session.createCriteria(Vendor.class).list();
		session.clear();
		for(Vendor vendor:results){
			vendor.setPerson_in_charge(null);
			vendor.setTelephone_number(null);
			vendor.setWebsite(null);
			vendor.setMobile_number(null);
			vendor.setEmail(null);
			vendor.setFinancial_report(null);
			vendor.setAddress(null);
			vendor.setEstablish_year(null);
			vendor.setNumber_of_employees(null);
			vendor.setBranch(null);
		}
		return results;
	}

	public Vendor getVendorById(Long id) {
		Session session = sessionFactory.getCurrentSession();
		Vendor result =  (Vendor) session.get(Vendor.class, id);
//		if (result != null) {
//			Hibernate.initialize(result.getSub_category().getCategory());
//		}
		return result;
	}

	public ListVendor getVendorBySubCategoryId(Long id, Integer page) {
		if (page == null) { page = 1; }
		Session session = sessionFactory.getCurrentSession();
		List<Vendor> results = session.createCriteria(Vendor.class)
				.createAlias("order", "order")
				.createAlias("order.sub_category", "sub_category")
				.add(Restrictions.eq("order.sub_category.id", id))
				.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY)
				.list();
		String get_rate_sql = "SELECT CAST(AVG(koubaiapp.orders.rate) AS UNSIGNED)\n" +
				"FROM (orders\n" +
				"	INNER JOIN vendors ON orders.vendor_id = vendors.id)\n" +
				"   INNER JOIN sub_categories ON sub_categories.id = orders.sub_category_id\n" +
				"WHERE orders.vendor_id = ? AND orders.sub_category_id = ? AND orders.rate != 0";
		for(Vendor result: results){
			session.clear();
			BigInteger rate = (BigInteger) session.createSQLQuery(get_rate_sql).setLong(0, result.getId()).setLong(1, id).uniqueResult();
			result.setCategory_rate(rate != null?rate:new BigInteger("0"));

			result.setPerson_in_charge(null);
			result.setTelephone_number(null);
			result.setWebsite(null);
			result.setMobile_number(null);
			result.setEmail(null);
			result.setAddress(null);
			result.setEstablish_year(null);
			result.setNumber_of_employees(null);
			result.setBranch(null);
			result.setFinancial_report(null);
			result.setRate(null);
		}
		return new ListVendor(1L, page, results);
	}

	public MyNotify createVendor(Vendor vendor) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		Object isExist = session.createCriteria(Vendor.class)
				.add(Restrictions.eq("name", vendor.getName()))
				.uniqueResult();
		if (null != isExist) {
			response.setType("error");
			response.setMessage("A vendor with this name already exists");
			} else {
			try {
				session.clear();
				session.save(vendor);
				response.setType("success");
				response.setMessage("Vendor has been created!");
			} catch (Exception e) {
				response.setType("error");
				response.setMessage(e.getMessage());
			}
		}
		return response;
	}

	public MyNotify updateVendor(Vendor vendor) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		Object isExist = session.get(Vendor.class, vendor.getId());
		if (null == isExist) {
			response.setType("error");
			response.setMessage("Can't update this Vendor. Vendor with id:" + vendor.getId() + " is not found on database.");
		} else {
			try {
				session.clear();
				session.update(vendor);
				response.setType("success");
				response.setMessage("Vendor has been updated!");
			} catch (Exception e) {
				response.setType("error");
				response.setMessage(e.getMessage());
			}
		}
		return response;
	}

	public MyNotify deleteVendor(Vendor vendor) {
		MyNotify response = new MyNotify();
		Session session = sessionFactory.getCurrentSession();
		Object isExist = session.get(Vendor.class, vendor.getId());
		if (null == isExist) {
			response.setType("error");
			response.setMessage("Can't delete this Vendor. Vendor with id:" + vendor.getId() + " is not found on database.");
		} else {
			try {
				session.clear();
				session.delete(vendor);
				response.setType("success");
				response.setMessage("Vendor  has been deleted!");
			} catch (Exception e){
				response.setType("error");
				response.setMessage(e.getMessage());
			}
		}
		return response;
	}

	public List<Vendor> searchVendor(String keyword){
		Session session = sessionFactory.getCurrentSession();

		FullTextSession fullTextSession = Search.getFullTextSession(session);

		QueryBuilder qb = fullTextSession.getSearchFactory()
				.buildQueryBuilder().forEntity(Vendor.class).get();
		org.apache.lucene.search.Query query = qb
				.keyword().onFields("name", "person_in_charge", "telephone_number", "website", "mobile_number", "email", "address")
				.matching(keyword)
				.createQuery();

		org.hibernate.search.FullTextQuery hibQuery =
				fullTextSession.createFullTextQuery(query, Vendor.class);

		org.apache.lucene.search.Sort sort = new Sort(
				new SortField("id", SortField.SCORE));

		hibQuery.setSort(sort);
		List<Vendor>  results = null;
		try {
			results = hibQuery
					.setMaxResults(200)
					.list();
		} catch (Exception e){
//			Do Nothing
		}
		return results;
	}
}
